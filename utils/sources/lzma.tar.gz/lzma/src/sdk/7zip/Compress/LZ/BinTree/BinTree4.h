// BinTree4.h

#ifndef __BINTREE4_H
#define __BINTREE4_H

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT4

#define HASH_ARRAY_2
#define HASH_ARRAY_3

#include "BinTree.h"
#include "BinTreeMain.h"

#undef HASH_ARRAY_2
#undef HASH_ARRAY_3

#endif
